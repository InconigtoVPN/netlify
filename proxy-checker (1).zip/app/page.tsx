"use client"

import { useState } from "react"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function ProxyChecker() {
  const [ipPort, setIpPort] = useState("")
  const [result, setResult] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const checkProxy = async () => {
    if (!ipPort || !ipPort.includes(":")) {
      setError("Please enter a valid IP:PORT combination")
      return
    }

    setLoading(true)
    setError("")
    setResult(null)

    try {
      const response = await fetch(`/api/check-proxy?ipPort=${encodeURIComponent(ipPort)}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()
      setResult(data)
    } catch (err) {
      setError(`Failed to check proxy: ${err instanceof Error ? err.message : String(err)}`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container max-w-md mx-auto py-10">
      <Card>
        <CardHeader>
          <CardTitle>Proxy IP Checker</CardTitle>
          <CardDescription>Check IP:PORT against proxyip.biz.id API</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter IP:PORT (e.g. 192.168.1.1:8080)"
                value={ipPort}
                onChange={(e) => setIpPort(e.target.value)}
                className="flex-1"
              />
              <Button onClick={checkProxy} disabled={loading}>
                {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Check
              </Button>
            </div>

            {error && (
              <Alert variant="destructive">
                <XCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {result && (
              <div className="border rounded-lg p-4">
                <h3 className="font-medium mb-2">Result:</h3>
                <pre className="bg-muted p-2 rounded text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre>
                <div className="mt-4 flex items-center">
                  <div className="mr-2">
                    {result.working ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>
                  <span>{result.working ? "Proxy is working" : "Proxy is not working"}</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

